import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import atg.rest.client.RestClientException;
import atg.rest.client.RestComponentHelper;
import atg.rest.client.RestResult;
import atg.rest.client.RestSession;

/**
 * Method Call implementation through REST API
 * 
 * @author ashish
 * 
 */
public class RESTClient {

	/** The m username. */
	private String mUsername;

	/** The m password. */
	private String mPassword;

	/** The m host. */
	private String mHost;

	/** The m port. */
	private int mPort;

	/** The m session. */
	private RestSession mSession = null;

	/**
	 * Instantiates a new method call by rest.
	 */
	public RESTClient() {
	}

	/**
	 * Execute.
	 * 
	 * @throws RestClientException
	 *             the rest client exception
	 */
	private void execute() {

		mSession = RestSession
				.createSession(mHost, mPort, mUsername, mPassword);
		mSession.setUseHttpsForLogin(false);

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("atg-rest-input", "json");
		RestResult result = null;
		try {
			result = RestComponentHelper.executeMethod(
					"/test/mysrvc/common/utils/OrderService", "addOrder",
					new Object[] {}, params, mSession);

		} catch (RestClientException e1) {
			System.out.println(e1);
		}

		try {
			if (result != null && result.getResponseCode() == 200) {
				System.out.println("Executed Successfully.");
			} else {
				System.out.println("Error while execution : Error Code ["
						+ result.getResponseCode() + "] and Message ["
						+ result.getResponseMessage() + "]");
			}
		} catch (IOException e) {
			System.out.println("Error while execution Successfully.");
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		RESTClient stepUtils = new RESTClient();
		stepUtils.mUsername = "admin";
		stepUtils.mPassword = "admin";
		stepUtils.mHost = "localhost";
		stepUtils.mPort = 8080;
		stepUtils.execute();

	}

}