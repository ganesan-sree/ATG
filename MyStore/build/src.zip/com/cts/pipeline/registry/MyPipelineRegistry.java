package com.cts.pipeline.registry;

import atg.service.pipeline.PipelineRegistry;

public class MyPipelineRegistry extends PipelineRegistry{

}
