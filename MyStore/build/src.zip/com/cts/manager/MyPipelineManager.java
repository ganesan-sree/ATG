package com.cts.manager;

import atg.service.pipeline.PipelineManager;

public class MyPipelineManager extends PipelineManager {

	public MyPipelineManager() {
		super();
		
	}

	
}
