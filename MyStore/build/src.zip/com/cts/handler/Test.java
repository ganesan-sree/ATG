package com.cts.handler;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stubyso
		
		try {
			
			
			Test t = new Test();
		System.out.println(	t.test());
			
		}
		catch(Exception e){
			
		}

	}
	
	
	String test () {
		try {
			return "aaaa";
		}
		catch(Exception e){
			
		}
		return null;
	}

}
