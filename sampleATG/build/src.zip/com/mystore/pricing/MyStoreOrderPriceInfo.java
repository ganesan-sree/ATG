package com.mystore.pricing;

import atg.commerce.pricing.OrderPriceInfo;


public class MyStoreOrderPriceInfo extends OrderPriceInfo{
	
	private int points;

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}
	
	
	

}
