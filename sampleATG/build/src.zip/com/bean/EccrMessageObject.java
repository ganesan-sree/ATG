package com.bean;

public class EccrMessageObject
	{

		private String name;
		private String id;
		public String getName()
			{
				return name;
			}
		public void setName(String pName)
			{
				name = pName;
			}
		public String getId()
			{
				return id;
			}
		public void setId(String pId)
			{
				id = pId;
			}

	}
