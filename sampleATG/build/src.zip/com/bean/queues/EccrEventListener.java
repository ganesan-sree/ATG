package com.bean.queues;

import java.util.EventListener;

import com.bean.EccrMessageObject;

public interface EccrEventListener extends EventListener {
	public void sendEccrMessage(EccrMessageObject message);
}
