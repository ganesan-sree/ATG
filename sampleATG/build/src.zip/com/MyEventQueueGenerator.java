package com;

import java.beans.IntrospectionException;
import java.io.PrintStream;
import atg.nucleus.logging.LogListener;
import atg.service.queue.EventQueueGenerator;

public class MyEventQueueGenerator extends EventQueueGenerator{

	public MyEventQueueGenerator(String pPackageName, String pClassName,
			String pSuperclassName, Class pClass, PrintStream pOut)
			throws IntrospectionException {
		super(pPackageName, pClassName, pSuperclassName, pClass, pOut);
		// TODO Auto-generated constructor stub
	}

}
