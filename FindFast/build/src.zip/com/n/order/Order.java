package com.n.order;

public interface Order extends atg.commerce.order.Order{

	public String getCouponAdded();
	public void setCouponAdded(String couponAdded);
	
}
