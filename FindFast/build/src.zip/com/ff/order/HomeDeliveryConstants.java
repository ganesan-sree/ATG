package com.ff.order;

public class HomeDeliveryConstants {

	public static String TITLE="title";
	
	public static String ADDRESS_1="address1";
	
	public static String ADDRESS_2="address2";
	
	public static String ADDRESS_3="address3";
	
	public static String CITY = "city";
	
	public static String STATES = "states";
	
	public static String COUNTRY = "country";
	
}
