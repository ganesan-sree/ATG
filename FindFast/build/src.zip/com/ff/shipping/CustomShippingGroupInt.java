package com.ff.shipping;

public interface CustomShippingGroupInt {
	public void setMobileNumber(String mobileNumber);
	public String getMobileNumber();
}
