package com.sexy.constants;

public class ConstantValue {
	public static String RESOURCE_BUNDLE="com.sexy.external.ajax.AjaxHandlerRouter";
	public static String ROUTER_VALUE="routeTo";
}
