/**
 * RatePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.fedex.rate.stub;

public interface RatePortType extends java.rmi.Remote {
    public com.fedex.rate.stub.RateReply getRates(com.fedex.rate.stub.RateRequest rateRequest) throws java.rmi.RemoteException;
}
